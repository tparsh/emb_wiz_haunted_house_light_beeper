#ifdef USBCON

#include "usbd_core.c"

#endif /* USBCON */
