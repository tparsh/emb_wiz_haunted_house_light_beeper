#ifdef STM32H7xx
#include "stm32h7xx_hal_eth_ex.c"
#endif
